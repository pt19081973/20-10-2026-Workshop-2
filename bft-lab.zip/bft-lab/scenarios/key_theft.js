const Node = require("../node");

const {
    stealKey,
    forgeVote
} = require("../attacks");

const nodeA = new Node("A");

const stolenSecret = stealKey(nodeA);

const forgedVote = forgeVote(
    "A",
    stolenSecret,
    999
);

console.log("Forged message");
console.log(forgedVote);

// --- Task 8.2: Key Revocation Defense ---
const revokedKeys = new Set();

function verifyVote(message) {
  if (revokedKeys.has(message.nodeId)) {
    console.log(`[SECURITY ALERT] Rejected forged message from Node ${message.nodeId}: Key has been REVOKED!`);
    return false;
  }
  console.log(`[WARNING] Signature verified as authentic: Node ${message.nodeId}'s key is currently trusted.`);
  return true;
}

console.log("\n--- Verification Before Revocation ---");
verifyVote(forgedVote);

console.log("\n--- Applying Key Revocation ---");
revokedKeys.add("A");
console.log("[GOVERNANCE] Key for Node A has been added to revocation list.");

console.log("\n--- Verification After Revocation ---");
verifyVote(forgedVote);
