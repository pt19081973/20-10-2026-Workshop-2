const Node = require("../node");

const {
    makeEquivocator
} = require("../attacks");

const nodeD =
    new Node("D");

makeEquivocator(nodeD, {

    A: 100,
    B: 50,
    C: 75
});

console.log(
    nodeD.voteForPeer("A")
);

console.log(
    nodeD.voteForPeer("B")
);

console.log(
    nodeD.voteForPeer("C")
);

// At the bottom of scenarios/equivocation.js:
const Simulator = require("../simulator");

// Create an instance of the simulator
const sim = new Simulator([]); 

// Feed the generated messages (messages array or the variables printed) into checkEquivocation:
const messages = [
  { nodeId: 'D', value: 100, recipient: 'A' },
  { nodeId: 'D', value: 50,  recipient: 'B' },
  { nodeId: 'D', value: 75,  recipient: 'C' }
];

console.log("\n--- Checking Messages for Equivocation ---");
for (const msg of messages) {
  sim.checkEquivocation(1, msg);
}
